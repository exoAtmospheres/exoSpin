<p align="left"><img src="logo.png" alt="exoSpin" width="250"/></p>

# exoSpin 


A tool to measure the obliquities of planets beyond our solar system. 

by: Idriss Abdoulwahab, Paulina Palma-Bifani, Gaël Chauvin, and Adrien Simonnin
